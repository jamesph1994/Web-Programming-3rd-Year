<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Cardiff Metropolitan University</title>

    <!-- Bootstrap core CSS -->
    <link href="cmet/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="cmet/css/business-frontpage.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
      	<div class="logo">
        <a class="navbar-brand" href=""></a>
        </div>
        <div class="">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">International</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Business</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Partnerships</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Research</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Alumni</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Cymraeg</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header with Background Image -->
    <header class="business-header">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
           
          </div>
        </div>
      </div>
    </header>

    <!-- Page Content -->
    <div class="container">

      <div class="row">
        <div class="col-sm-8">
          <h2 class="mt-4">We are #CardiffMet</h2>
          <p>Located in a vibrant European capital city, Cardiff Metropolitan University is a thriving and modern university. Integral to the city of Cardiff for more than 150 years, we continue to invest in our students’ future with a focus on student employability and enhancing the student experience​; providing education and training opportunities of the highest quality to students from over 140 countries worldwide.​​​​</p>
          <p>
            <a class="btn btn-primary btn-lg" href="#">Student Portal &raquo;</a>
          </p>
        </div>
        <div class="col-sm-4">
          <h2 class="mt-4">Contact Us</h2>
          <address>
            <strong>Cardiff Met</strong>
            <br>Llandaff Campus , Western Avenue .
            <br>Cardiff , CF5 2YB . Tel: 029 2041 6070 .
            <br>
          </address>
          <address>
            <abbr title="Phone">P:</abbr>
            (+44) 029 20​20 5669 
            <br>
            <abbr title="Email">E:</abbr>
            <a href="mailto:#"> izone@cardiffmet.ac.uk</a>
          </address>
        </div>
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-sm-4 my-4">
          <div class="card">
            <img class="card-img-top" src="http://www.sussex.ac.uk/wcm/assets/media/original/40627.jpg" alt="">
            <div class="card-body">
              <h4 class="card-title">Undergraduate Courses</h4>
              <p class="card-text">At Cardiff Metropolitan University we offer a wide range of undergraduate ​degree ​courses ac​ro​ss our fiv​e academic schools.​ </p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More</a>
            </div>
          </div>
        </div>
        <div class="col-sm-4 my-4">
          <div class="card">
            <img class="card-img-top" src="http://www.nyc.gr/userfiles/image/course_images/postgraduate.JPG" alt="">
            <div class="card-body">
              <h4 class="card-title">Postgraduate Courses</h4>
              <p class="card-text">At Cardiff Metropolitan University we offer a wide range of our taught postgraduate programmes across our five academic schools. A full list of these can be found below. If you are interested in undertaking research at the university.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More</a>
            </div>
          </div>
        </div>
        <div class="col-sm-4 my-4">
          <div class="card">
            <img class="card-img-top" src="https://c1.staticflickr.com/8/7411/9253531837_870ed12137_b.jpg" alt="">
            <div class="card-body">
              <h4 class="card-title">Book an Open Day</h4>
              <p class="card-text">At Cardiff Met we run campus based undergraduate Open Days throughout the year. They offer students and parents a great opportunity to find out more about the range of courses we offer, speak to staff and current students and take a tour our accommodation and facilities.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More</a>
            </div>
          </div>
        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Cardiff Metropolitan University</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

