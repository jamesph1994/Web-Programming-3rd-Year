<html>
<title>Admin Page</title>
	
<?php

$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Users";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$firstname = $_POST['firstname'];

$surname = $_POST['surname'];

$email = $_POST['email'];

$password = $_POST['password'];


$query = "INSERT INTO User (FirstName, Surname, Email, Password) VALUES ('$firstname', '$surname', '$email', '$password')";

if ($conn->query($query) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

$conn->close();
?>
</html>