<html>
<title>User Page</title>

<form action="admin.php" method="post">
	
	Name : <input type="text" name="username">
		<br/>
	Email : <input type="text" name="email">
		<br/>
		<input type="submit" value="Insert">	

</form>
</html>